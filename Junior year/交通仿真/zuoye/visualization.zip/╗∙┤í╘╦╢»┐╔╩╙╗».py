import pygame,sys

pygame.init()     #pygame初始化


size = width, height = 1024, 768     #初始化窗口大小
car_length=50         #初始化车辆长宽
car_width=25
car_initial1=(0,448)        #车辆初始位置
islane_changing=1           #定义决策变量：是否换道
lane_changing_width=150       #换道横向位置
desired_height=487            #目标车道高度
speed = [1,0]                 #初始化车辆速度


screen = pygame.display.set_mode(size)             #创建窗口，并设置大小
pygame.display.set_caption("Cellular Automata")    #定义窗口名称


car = pygame.image.load("./car.png")                 #导入车辆图片    
car=pygame.transform.scale(car, (car_length,car_width))     #调整车辆图片大小
background = pygame.image.load("./background.png")        #导入背景图


car_rect=car.get_rect()                                   #获取car的rect对象
car_rect.x,car_rect.y=car_initial1                         #车辆初始位置
fps = 200                                                 #帧速率
fclock = pygame.time.Clock()                              #创建Clock实例



while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
    car_rect = car_rect.move(speed[0],speed[1])             #车辆行驶速度
    if car_rect.left < 0 or car_rect.right > width:         #车辆直线行驶
        speed[0] = - speed[0]
    #if car_rect.top < 0 or car_rect.bottom > height:
    #    speed[1] = - speed[1]
    if car_rect.right==lane_changing_width and islane_changing==1:          #换道行为
        speed[1]=1
    if car_rect.top==desired_height:
        speed[1]=0
        car_rect.top=desired_height
    if car_rect.right==width:                                    #到达路段终点退出窗口
        speed[0]=0
        car_rect.x,car_rect.y=(width+1,485)
    screen.blit(background,(0,0))                                  #在窗口上绘制背景图
    screen.blit(car, car_rect)                                     #在窗口上绘制车辆图
    pygame.display.update()                                        #更新画面
    fclock.tick(fps)                                               #更新游戏帧率，同时也可以获取当前时间

