import pygame
from random import random
import numpy as np
from scipy import stats
import math

pygame.init()     #pygame初始化

size = width, height = 1024, 768     #初始化窗口大小
car_length=50         #初始化车辆长宽
car_width=25
car_initial1=(0,448)        #车道1车辆初始位置
car_initial2=(0,485)        #车道2车辆初始位置
delta_height=37             #车道1和车道2的高度差
speed = []                  #车道1车辆速度和车道2车辆速度的集合
islane_changing=1           #决策变量：是否换道
lane_changing_width=150      #换道横向位置
fps = 100                    #帧速率

car = pygame.image.load("car.png")                 #导入车辆图片    
background = pygame.image.load("./background.png")        #导入背景图

###############初始速度服从正态分布###############
mean = 3.5  # 正态分布的均值
std = 1  # 正态分布的标准差


# 创建车道1定时器常量
CAR1_CREATE = pygame.USEREVENT
# 创建车道2定时器常量
CAR2_CREATE = pygame.USEREVENT + 1

class Car1(pygame.sprite.Sprite):
    def __init__(self, *args):
        super().__init__(*args)
        self.image = pygame.transform.scale(car, (car_length,car_width))   #调整车辆图片大小
        self.rect = pygame.display.get_surface().get_rect()                #获取rect对象
        self.rect.x,self.rect.y=car_initial1                                #车辆初始位置
        self.prob1 = np.random.uniform(0, 1)                                # 车道1速度分布的概率
        self.speed1 = int(stats.norm.ppf(self.prob1, loc=mean, scale=std))   # 车道1车辆初速度
    

    def update(self, events, dt):
        self.rect.move_ip((self.speed1 *0.1* dt,0))                                      #车辆移动
        #if self.rect.x > 1024: self.rect.x = 0                               #重复
        #if self.rect.y > 500: self.rect.y = 0

class Car2(pygame.sprite.Sprite):
    def __init__(self, *args):
        super().__init__(*args)
        self.image = pygame.transform.scale(car, (car_length,car_width))   #调整车辆图片大小
        self.rect = pygame.display.get_surface().get_rect()                #获取rect对象
        self.rect.x,self.rect.y=car_initial2                               #车辆初始位置
        self.prob2 = np.random.uniform(0, 1)                                # 车道1速度分布的概率
        self.speed2 = int(stats.norm.ppf(self.prob2, loc=mean, scale=std))   # 车道1车辆初速度

    def update(self, events, dt):
        self.rect.move_ip((self.speed2*0.1* dt,0))
        #if self.rect.x > 1024: 
            #self.rect.x ,self.rect.y = car_initial2
        if self.rect.x >lane_changing_width and self.rect.x <lane_changing_width+delta_height and islane_changing == 1:      #换道行为
            self.rect.move_ip((0.15 * dt,-0.15* dt))
        if self.rect.x > lane_changing_width+delta_height and islane_changing == 1:
            self.rect.y =448
            self.rect.move_ip((0.15* dt,0))
        #if self.rect.y > 500: self.rect.y = 0

def main():
    pygame.init()
    screen = pygame.display.set_mode(size)             #创建窗口，并设置大小
    pygame.display.set_caption("Cellular Automata")    #定义窗口名称
    sprites1 = pygame.sprite.Group()                   #创建车道1车辆
    Car1(sprites1)
    sprites2 = pygame.sprite.Group()                   #创建车道2车辆
    Car2(sprites2)
    clock = pygame.time.Clock()                        #创建Clock实例
    pygame.time.set_timer(CAR1_CREATE, 2000)  # 1000ms
    pygame.time.set_timer(CAR2_CREATE, 2000)  # 500ms
    dt = 0
    while True:

        events = pygame.event.get()
        for e in events:
            if e.type == pygame.QUIT:
                return
            elif e.type==CAR1_CREATE:
                car1=Car1()
                sprites1.add(car1)
            elif e.type==CAR2_CREATE:
                car2=Car2()
                sprites1.add(car2)

        sprites1.update(events,dt)        #车道1车辆更新
        sprites2.update(events,dt)        #车道2车辆更新


        screen.blit(background,(0,0))     #在窗口上绘制背景图
        sprites1.draw(screen)             #在窗口上绘制车道1车辆
        sprites2.draw(screen)             #在窗口上绘制车道2车辆
        pygame.display.update()           #更新画面

        dt = clock.tick(fps)              #更新游戏帧率，同时也可以获取当前时间

if __name__ == '__main__':
    main()