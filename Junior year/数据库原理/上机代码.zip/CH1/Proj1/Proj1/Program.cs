﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj1
{
    class Program  //Program类
    {
        static void Main(string[] args)  /*程序的起点*/
        {
            Console.WriteLine("Hello World");
        }
    }
}
