﻿
namespace Proj3
{
    public class TempData
    {
        public static int mynum;
        public static string mystr;
    }

}
