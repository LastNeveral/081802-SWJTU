﻿namespace SM
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.spxxgl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.添加新商品menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.编辑商品信息menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.增加老商品库存menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.商品库存报警menu = new System.Windows.Forms.ToolStripMenuItem();
            this.gkxxgl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.添加新顾客menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.编辑顾客信息menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.查看顾客购物信息menu = new System.Windows.Forms.ToolStripMenuItem();
            this.gwgl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.顾客购物menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.顾客退货menu = new System.Windows.Forms.ToolStripMenuItem();
            this.cxgl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.按分类统计销售情况menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.按子类统计销售情况menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.按商品统计销售情况menu = new System.Windows.Forms.ToolStripMenuItem();
            this.xtgl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.用户管理menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.设置商品类别menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.设置地区信息menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.系统初始化menu = new System.Windows.Forms.ToolStripMenuItem();
            this.bz = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.关于menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.联系信息menu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 30);
            this.toolStrip1.Margin = new System.Windows.Forms.Padding(1);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(832, 31);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Padding = new System.Windows.Forms.Padding(15, 4, 15, 4);
            this.toolStripButton1.Size = new System.Drawing.Size(50, 28);
            this.toolStripButton1.Text = "购物";
            this.toolStripButton1.ToolTipText = "购物";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.toolStripButton2.Size = new System.Drawing.Size(50, 28);
            this.toolStripButton2.Text = "退货";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.toolStripButton3.Size = new System.Drawing.Size(50, 28);
            this.toolStripButton3.Text = "退出";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spxxgl,
            this.gkxxgl,
            this.gwgl,
            this.cxgl,
            this.xtgl,
            this.bz});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(832, 30);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // spxxgl
            // 
            this.spxxgl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator15,
            this.添加新商品menu,
            this.toolStripSeparator1,
            this.编辑商品信息menu,
            this.toolStripSeparator8,
            this.增加老商品库存menu,
            this.toolStripSeparator10,
            this.商品库存报警menu});
            this.spxxgl.ForeColor = System.Drawing.Color.Red;
            this.spxxgl.Name = "spxxgl";
            this.spxxgl.Padding = new System.Windows.Forms.Padding(15, 3, 15, 3);
            this.spxxgl.Size = new System.Drawing.Size(144, 26);
            this.spxxgl.Text = "商品信息管理";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(192, 6);
            // 
            // 添加新商品menu
            // 
            this.添加新商品menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.添加新商品menu.ForeColor = System.Drawing.Color.Green;
            this.添加新商品menu.Name = "添加新商品menu";
            this.添加新商品menu.Size = new System.Drawing.Size(195, 22);
            this.添加新商品menu.Text = "添加新商品";
            this.添加新商品menu.Click += new System.EventHandler(this.添加新商品menu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.toolStripSeparator1.Size = new System.Drawing.Size(192, 6);
            // 
            // 编辑商品信息menu
            // 
            this.编辑商品信息menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.编辑商品信息menu.ForeColor = System.Drawing.Color.Green;
            this.编辑商品信息menu.Name = "编辑商品信息menu";
            this.编辑商品信息menu.Size = new System.Drawing.Size(195, 22);
            this.编辑商品信息menu.Text = "编辑商品信息";
            this.编辑商品信息menu.Click += new System.EventHandler(this.编辑商品信息menu_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.toolStripSeparator8.Size = new System.Drawing.Size(192, 6);
            // 
            // 增加老商品库存menu
            // 
            this.增加老商品库存menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.增加老商品库存menu.ForeColor = System.Drawing.Color.Green;
            this.增加老商品库存menu.Name = "增加老商品库存menu";
            this.增加老商品库存menu.Size = new System.Drawing.Size(195, 22);
            this.增加老商品库存menu.Text = "增加老商品库存";
            this.增加老商品库存menu.Click += new System.EventHandler(this.增加老商品库存menu_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(192, 6);
            // 
            // 商品库存报警menu
            // 
            this.商品库存报警menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.商品库存报警menu.ForeColor = System.Drawing.Color.Green;
            this.商品库存报警menu.Name = "商品库存报警menu";
            this.商品库存报警menu.Size = new System.Drawing.Size(195, 22);
            this.商品库存报警menu.Text = "商品库存报警";
            this.商品库存报警menu.Click += new System.EventHandler(this.商品库存报警menu_Click);
            // 
            // gkxxgl
            // 
            this.gkxxgl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator16,
            this.添加新顾客menu,
            this.toolStripSeparator2,
            this.编辑顾客信息menu,
            this.toolStripSeparator9,
            this.查看顾客购物信息menu});
            this.gkxxgl.ForeColor = System.Drawing.Color.Red;
            this.gkxxgl.Name = "gkxxgl";
            this.gkxxgl.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.gkxxgl.Size = new System.Drawing.Size(144, 26);
            this.gkxxgl.Text = "顾客信息管理";
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(209, 6);
            // 
            // 添加新顾客menu
            // 
            this.添加新顾客menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.添加新顾客menu.ForeColor = System.Drawing.Color.Green;
            this.添加新顾客menu.Name = "添加新顾客menu";
            this.添加新顾客menu.Size = new System.Drawing.Size(212, 22);
            this.添加新顾客menu.Text = "添加新顾客";
            this.添加新顾客menu.Click += new System.EventHandler(this.添加新顾客menu_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.toolStripSeparator2.Size = new System.Drawing.Size(209, 6);
            // 
            // 编辑顾客信息menu
            // 
            this.编辑顾客信息menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.编辑顾客信息menu.ForeColor = System.Drawing.Color.Green;
            this.编辑顾客信息menu.Name = "编辑顾客信息menu";
            this.编辑顾客信息menu.Size = new System.Drawing.Size(212, 22);
            this.编辑顾客信息menu.Text = "编辑顾客信息";
            this.编辑顾客信息menu.Click += new System.EventHandler(this.编辑顾客信息menu_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.toolStripSeparator9.Size = new System.Drawing.Size(209, 6);
            // 
            // 查看顾客购物信息menu
            // 
            this.查看顾客购物信息menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.查看顾客购物信息menu.ForeColor = System.Drawing.Color.Green;
            this.查看顾客购物信息menu.Name = "查看顾客购物信息menu";
            this.查看顾客购物信息menu.Size = new System.Drawing.Size(212, 22);
            this.查看顾客购物信息menu.Text = "查看顾客购物信息";
            this.查看顾客购物信息menu.Click += new System.EventHandler(this.查看顾客购物信息menu_Click);
            // 
            // gwgl
            // 
            this.gwgl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator17,
            this.顾客购物menu,
            this.toolStripSeparator4,
            this.顾客退货menu});
            this.gwgl.ForeColor = System.Drawing.Color.Red;
            this.gwgl.Name = "gwgl";
            this.gwgl.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.gwgl.Size = new System.Drawing.Size(110, 26);
            this.gwgl.Text = "购物管理";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(141, 6);
            // 
            // 顾客购物menu
            // 
            this.顾客购物menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.顾客购物menu.ForeColor = System.Drawing.Color.Green;
            this.顾客购物menu.Name = "顾客购物menu";
            this.顾客购物menu.Size = new System.Drawing.Size(144, 22);
            this.顾客购物menu.Text = "顾客购物";
            this.顾客购物menu.Click += new System.EventHandler(this.顾客购物menu_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // 顾客退货menu
            // 
            this.顾客退货menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.顾客退货menu.ForeColor = System.Drawing.Color.Green;
            this.顾客退货menu.Name = "顾客退货menu";
            this.顾客退货menu.Size = new System.Drawing.Size(144, 22);
            this.顾客退货menu.Text = "顾客退货";
            this.顾客退货menu.Click += new System.EventHandler(this.顾客退货menu_Click);
            // 
            // cxgl
            // 
            this.cxgl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator18,
            this.按分类统计销售情况menu,
            this.toolStripSeparator3,
            this.按子类统计销售情况menu,
            this.toolStripSeparator11,
            this.按商品统计销售情况menu});
            this.cxgl.ForeColor = System.Drawing.Color.Red;
            this.cxgl.Name = "cxgl";
            this.cxgl.Size = new System.Drawing.Size(88, 26);
            this.cxgl.Text = "查询功能";
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(226, 6);
            // 
            // 按分类统计销售情况menu
            // 
            this.按分类统计销售情况menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.按分类统计销售情况menu.ForeColor = System.Drawing.Color.Green;
            this.按分类统计销售情况menu.Name = "按分类统计销售情况menu";
            this.按分类统计销售情况menu.Size = new System.Drawing.Size(229, 22);
            this.按分类统计销售情况menu.Text = "按分类统计销售情况";
            this.按分类统计销售情况menu.Click += new System.EventHandler(this.按分类统计销售情况menu_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(226, 6);
            // 
            // 按子类统计销售情况menu
            // 
            this.按子类统计销售情况menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.按子类统计销售情况menu.ForeColor = System.Drawing.Color.Green;
            this.按子类统计销售情况menu.Name = "按子类统计销售情况menu";
            this.按子类统计销售情况menu.Size = new System.Drawing.Size(229, 22);
            this.按子类统计销售情况menu.Text = "按子类统计销售情况";
            this.按子类统计销售情况menu.Click += new System.EventHandler(this.按子类统计销售情况menu_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(226, 6);
            // 
            // 按商品统计销售情况menu
            // 
            this.按商品统计销售情况menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.按商品统计销售情况menu.ForeColor = System.Drawing.Color.Green;
            this.按商品统计销售情况menu.Name = "按商品统计销售情况menu";
            this.按商品统计销售情况menu.Size = new System.Drawing.Size(229, 22);
            this.按商品统计销售情况menu.Text = "按商品统计销售情况";
            this.按商品统计销售情况menu.Click += new System.EventHandler(this.按商品统计销售情况menu_Click);
            // 
            // xtgl
            // 
            this.xtgl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator19,
            this.用户管理menu,
            this.toolStripSeparator5,
            this.设置商品类别menu,
            this.toolStripSeparator6,
            this.设置地区信息menu,
            this.toolStripSeparator14,
            this.系统初始化menu});
            this.xtgl.ForeColor = System.Drawing.Color.Red;
            this.xtgl.Name = "xtgl";
            this.xtgl.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.xtgl.Size = new System.Drawing.Size(110, 26);
            this.xtgl.Text = "系统管理";
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(175, 6);
            // 
            // 用户管理menu
            // 
            this.用户管理menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.用户管理menu.ForeColor = System.Drawing.Color.Green;
            this.用户管理menu.Name = "用户管理menu";
            this.用户管理menu.Size = new System.Drawing.Size(178, 22);
            this.用户管理menu.Text = "用户管理";
            this.用户管理menu.Click += new System.EventHandler(this.用户管理menu_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(175, 6);
            // 
            // 设置商品类别menu
            // 
            this.设置商品类别menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.设置商品类别menu.ForeColor = System.Drawing.Color.Green;
            this.设置商品类别menu.Name = "设置商品类别menu";
            this.设置商品类别menu.Size = new System.Drawing.Size(178, 22);
            this.设置商品类别menu.Text = "设置商品类别";
            this.设置商品类别menu.Click += new System.EventHandler(this.设置商品类别menu_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(175, 6);
            // 
            // 设置地区信息menu
            // 
            this.设置地区信息menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.设置地区信息menu.ForeColor = System.Drawing.Color.Green;
            this.设置地区信息menu.Name = "设置地区信息menu";
            this.设置地区信息menu.Size = new System.Drawing.Size(178, 22);
            this.设置地区信息menu.Text = "设置地区信息";
            this.设置地区信息menu.Click += new System.EventHandler(this.设置地区信息menu_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(175, 6);
            // 
            // 系统初始化menu
            // 
            this.系统初始化menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.系统初始化menu.ForeColor = System.Drawing.Color.Fuchsia;
            this.系统初始化menu.Name = "系统初始化menu";
            this.系统初始化menu.Size = new System.Drawing.Size(178, 22);
            this.系统初始化menu.Text = "系统初始化";
            this.系统初始化menu.Click += new System.EventHandler(this.系统初始化menu_Click);
            // 
            // bz
            // 
            this.bz.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator20,
            this.关于menu,
            this.toolStripSeparator7,
            this.联系信息menu});
            this.bz.ForeColor = System.Drawing.Color.Red;
            this.bz.Name = "bz";
            this.bz.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.bz.Size = new System.Drawing.Size(76, 26);
            this.bz.Text = "帮助";
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(141, 6);
            // 
            // 关于menu
            // 
            this.关于menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.关于menu.ForeColor = System.Drawing.Color.Green;
            this.关于menu.Name = "关于menu";
            this.关于menu.Size = new System.Drawing.Size(144, 22);
            this.关于menu.Text = "关于...";
            this.关于menu.Click += new System.EventHandler(this.关于menu_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(141, 6);
            // 
            // 联系信息menu
            // 
            this.联系信息menu.Font = new System.Drawing.Font("仿宋", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.联系信息menu.ForeColor = System.Drawing.Color.Green;
            this.联系信息menu.Name = "联系信息menu";
            this.联系信息menu.Size = new System.Drawing.Size(144, 22);
            this.联系信息menu.Text = "联系信息";
            this.联系信息menu.Click += new System.EventHandler(this.联系信息menu_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 551);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "超市管理信息系统";
            this.Load += new System.EventHandler(this.Main_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem spxxgl;
        private System.Windows.Forms.ToolStripMenuItem 添加新商品menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 增加老商品库存menu;
        private System.Windows.Forms.ToolStripMenuItem gkxxgl;
        private System.Windows.Forms.ToolStripMenuItem gwgl;
        private System.Windows.Forms.ToolStripMenuItem xtgl;
        private System.Windows.Forms.ToolStripMenuItem bz;
        private System.Windows.Forms.ToolStripMenuItem 添加新顾客menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 编辑顾客信息menu;
        private System.Windows.Forms.ToolStripMenuItem 查看顾客购物信息menu;
        private System.Windows.Forms.ToolStripMenuItem 顾客购物menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem 顾客退货menu;
        private System.Windows.Forms.ToolStripMenuItem 用户管理menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem 设置商品类别menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem 设置地区信息menu;
        private System.Windows.Forms.ToolStripMenuItem 关于menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem 联系信息menu;
        private System.Windows.Forms.ToolStripMenuItem cxgl;
        private System.Windows.Forms.ToolStripMenuItem 按分类统计销售情况menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 按子类统计销售情况menu;
        private System.Windows.Forms.ToolStripMenuItem 编辑商品信息menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem 商品库存报警menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem 按商品统计销售情况menu;
        private System.Windows.Forms.ToolStripMenuItem 系统初始化menu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
    }
}

